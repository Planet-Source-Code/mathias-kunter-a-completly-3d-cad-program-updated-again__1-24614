SHOT IT UPDATE TO VERSION 1.3

Again, this update is only nescessary if you're having Shot It version 1.2. You can also download the latest
version 1.4 of this game, which has also sounds. It's aviable on http://www.planetsourcecode.com, Quick Search
for "Shot It" in Visual Basic language.


To update the game from version 1.2 to version 1.3, do the following:

1) Replace the three files Game.bas, StartForm.frm and StartForm.frx in the Shot It diretory with these one
   from the update.
2) Copy the Size.dat in the Shot It\Data directory.
3) It's recommended that you compile the project again to increase frame rates.

That's it! Now you are free to create your own Shot It levels!
I'm looking forward for your levels! If you want, you can send me your levels per e-mail.

Mail your levels to: mathiaskunter@yahoo.de
Thanks!