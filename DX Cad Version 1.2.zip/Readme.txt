Installation of DX CAD

Simply extract the contens of this zip file to any directory.
Open the project with VB and click the start button.

This project needs DirectX 7 or higher to run.
It also need a graphics card with at least 8 MB, I think.
Hint: Compile the project before starting it in VB to increase speed.

Check out the Help.doc file in the Help folder if you need instructions on how to use this program.
Check out the Update.txt file in the Help folder if you want to know what has been changed in this new
version.

Have fun!


If there are comments, questions or critics, mail me!

Autor: Mathias Kunter
Mail: mathiaskunter@yahoo.de